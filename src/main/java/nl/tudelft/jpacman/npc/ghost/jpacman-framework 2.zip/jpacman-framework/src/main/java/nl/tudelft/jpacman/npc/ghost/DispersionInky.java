package nl.tudelft.jpacman.npc.ghost;

import nl.tudelft.jpacman.board.Direction;

public class DispersionInky extends DispersionMode{

	
	public DispersionInky(Ghost g){
		super(g);
	}
	public Direction nextMove(){
		return super.nextMove();
	}
	
	
}

