package nl.tudelft.jpacman.npc.ghost;

import nl.tudelft.jpacman.board.Direction;

public class DispersionPinky extends DispersionMode{

	
	public DispersionPinky(Ghost g){
		super(g);
	}
	
	public Direction nextMove(){
		return super.nextMove();
	}
	
}

